



1) Create a Folder in a desired location
2) Drag Forge server files into the newly created location (Forge-1.12.2 file + Minecraft_Server.1.12.2)
3) Run Minecraft_server.1.12.2
4) Open EULA file, Change eulu=false to eula=true
5) Run Minecraft_Server.1.12.2 again. Wait for the server to load the rest of the files. You will know its ready when the "avg tick" is showing a real value
6) Type stop in the server command field
7) Run the Forge-1.12.2 file. Wait for the server to load the rest of the files. You will know its ready when the "avg tick" is showing a real value. Type stop in the server command field.
8) Copy mods from the downloaded file to the newly created mods files
9) Run Forge-1.12.2. This is the primary way to launch the server.

I am not responsible for how you allow other players to connect to your server. Please use your best judgment.